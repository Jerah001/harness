// Granularity control: the size model, plan scoring, calibration from outcomes, and how the loop
// acts on them (plan repair, ceiling strikes, proactive split, weighted progress).
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { DEFAULTS } from '../src/config.mjs';
import { applyPlan, parsePrd, syncAcs } from '../src/graph.mjs';
import { calibrate, costPerPoint, ensureSizing, fitHazard, firstPass, getModel, optimum, penalty, points, progress, rawPoints, reward, scorePlan, sizingReport, verdict } from '../src/sizing.mjs';
import { emptyState } from '../src/store.mjs';
import { deepMerge } from '../src/util.mjs';
import { project } from './helpers.mjs';

const cfg = DEFAULTS;
const sz = cfg.sizing;
const near = (a, b, eps = 0.02) => assert.ok(Math.abs(a - b) <= eps, `${a} is not within ${eps} of ${b}`);
const entry = (over = {}) => ({ id: 'T', title: 't', area: 'web', raw: 6.5, rounds: 1, merged: true, ceilings: 0, buildUsd: 0, reviewUsd: 0, ...over });
const withLedger = (ledger) => {
  const s = emptyState();
  ensureSizing(s).ledger = ledger;
  calibrate(s, cfg);
  return s;
};
const planState = (prd = '- **AC-001** (must) a\n- **AC-002** (must) b\n- **AC-003** (must) c\n') => {
  const s = emptyState();
  syncAcs(s, parsePrd(prd));
  return s;
};
const task = (key, over = {}) => ({ key, title: key, description: 'd', area: 'web', milestone: 'M0', ...over });

test('the optimum is where a point of work is cheapest, and the penalty grows in both directions from it', () => {
  const m = getModel(emptyState(), cfg);
  near(m.O, 2);
  near(m.sStar, 5.4, 0.05); // priors: overhead 2 points, hazard 0.05
  near(m.sStar, optimum(2, 0.05), 1e-9);
  for (const s of [m.sStar - 0.5, m.sStar + 0.5]) assert.ok(costPerPoint(s, m) > costPerPoint(m.sStar, m));
  near(penalty(m.sStar, m), 0, 1e-9);
  assert.ok(penalty(1, m) > penalty(2, m) && penalty(2, m) > penalty(4, m)); // too small: overhead dominates
  assert.ok(penalty(30, m) > penalty(20, m) && penalty(20, m) > penalty(10, m)); // too big: retries dominate
  near(penalty(m.lo, m), sz.bandPenalty, 1e-6);
  near(firstPass(m.cap, m), sz.minFirstPass, 1e-9); // the cap is where a round is a coin flip
  near(m.cap, Math.log(2) / 0.05, 1e-9);
});

test('points come from what the planner declares, so a label cannot hide a large task', () => {
  const m = getModel(emptyState(), cfg);
  assert.equal(rawPoints({ size: 'S' }, sz), 2);
  assert.equal(rawPoints({ size: 'M', acceptance: ['AC-001'], done_when: ['x', 'y'] }, sz), 5 + 1.5 + 1);
  assert.equal(rawPoints({ size: 'S', acceptance: ['a', 'b', 'c'], touches: ['web/a/**', 'server/b/**', 'db/c.sql'] }, sz), 2 + 4.5 + 1 + 4);
  assert.equal(rawPoints({ size: 'M', touches: ['web/a/**', 'web/b/**'] }, sz), 5.5); // same folder: one area
  assert.equal(rawPoints({ size: 'M', touches: ['web/a/**', 'pnpm-lock.yaml'] }, sz), 5.5); // a root file is not another area
  assert.equal(rawPoints({}, sz), 5); // no label: M
  assert.equal(rawPoints({ kind: 'fix' }, sz), 2); // triage fixes are small unless said otherwise
  assert.equal(rawPoints({ size: 'M', doneWhen: ['x'] }, sz), 5.5); // tasks in state use doneWhen
  assert.equal(points({ size: 'M', area: 'server' }, { ...m, kappa: { server: 1.4 } }, sz), 7);
});

test('the hazard is re-fitted from outcomes: clean passes loosen the target, failures tighten it', () => {
  near(fitHazard([], 0.05, 4), 0.05, 1e-4); // no data: the prior
  const prior = getModel(emptyState(), cfg);
  const clean = getModel(withLedger(Array.from({ length: 10 }, () => entry())), cfg);
  const rough = getModel(withLedger([...Array.from({ length: 5 }, () => entry()), ...Array.from({ length: 5 }, () => entry({ rounds: 2 }))]), cfg);
  const failed = getModel(withLedger([...Array.from({ length: 6 }, () => entry({ raw: 5 })), entry({ raw: 12, rounds: 4, merged: false }), entry({ raw: 12, rounds: 4, merged: false })]), cfg);
  assert.ok(clean.lambda < prior.lambda && clean.sStar > prior.sStar);
  assert.ok(rough.lambda > prior.lambda && rough.sStar < prior.sStar && rough.cap < prior.cap);
  assert.ok(failed.lambda > rough.lambda && failed.cap < 9);
  // loosening is earned: the cap never exceeds twice the largest task that actually merged
  assert.ok(Math.log(2) / clean.lambda > 20);
  near(clean.cap, prior.cap, 1e-9);
  const bigLanded = getModel(withLedger(Array.from({ length: 10 }, () => entry({ raw: 10 }))), cfg);
  near(bigLanded.cap, 20, 1e-9);
  // and one bad stretch cannot swing the model without limit
  const awful = withLedger(Array.from({ length: 30 }, () => entry({ rounds: 4, merged: false })));
  assert.equal(awful.sizing.lambda, sz.hazard * 4);
});

test('measured cost per area rescales the estimate, and measured review cost raises the overhead', () => {
  const s = withLedger([
    ...Array.from({ length: 4 }, () => entry({ area: 'web', buildUsd: 1, reviewUsd: 0.2 })),
    ...Array.from({ length: 4 }, () => entry({ area: 'server', buildUsd: 3, reviewUsd: 0.2 })),
  ]);
  const m = getModel(s, cfg);
  assert.ok(m.kappa.server > 1.2 && m.kappa.web < 0.8, JSON.stringify(m.kappa)); // server points are heavier than web points here
  assert.ok(points({ size: 'M', area: 'server' }, m, sz) > points({ size: 'M', area: 'web' }, m, sz));
  const pricey = getModel(withLedger(Array.from({ length: 8 }, () => entry({ buildUsd: 1, reviewUsd: 1 }))), cfg);
  assert.ok(pricey.O > m.O && pricey.sStar > getModel(emptyState(), cfg).sStar); // expensive reviews favour fewer, larger tasks
  assert.deepEqual(getModel(withLedger([entry()]), cfg).kappa, {}); // no cost data: estimates are left alone
});

test('rewards: a first-time pass beats the ideal budget, repeats overspend it, a blocked task is all loss', () => {
  const m = getModel(emptyState(), cfg);
  const first = reward(entry(), m);
  const twice = reward(entry({ rounds: 2 }), m);
  const blocked = reward(entry({ rounds: 4, merged: false }), m);
  assert.ok(first > 0 && twice < 0 && blocked < twice, `${first} ${twice} ${blocked}`);
  near(first, 1 - (m.O + 6.5) / (6.5 * m.fStar), 0.006);
  assert.equal(verdict(entry(), m, null), 'right');
  assert.equal(verdict(entry({ rounds: 3 }), m, null), 'too big');
  assert.equal(verdict(entry({ raw: 3, rounds: 3 }), m, null), 'hard'); // small but difficult: splitting would not have helped
  assert.equal(verdict(entry({ rounds: 2, merged: false, ceilings: 2 }), m, null), 'too big');
  assert.equal(verdict(entry({ buildUsd: 0.1 }), m, 0.1), 'small'); // cost one point's worth: overhead dominated
});

test('scorePlan: a healthy plan passes; an oversized task comes back with how many parts to split it into', () => {
  const s = planState();
  const ok = scorePlan(s, { tasks: [task('a', { acceptance: ['AC-001'], touches: ['web/a/**'] }), task('b', { acceptance: ['AC-002'], touches: ['server/b/**'], area: 'server' })] }, cfg);
  assert.deepEqual(ok.problems, []);
  assert.ok(ok.waste < 0.05 && ok.parallelEfficiency === 1);

  const big = scorePlan(s, { tasks: [task('everything', { size: 'L', acceptance: ['AC-001', 'AC-002', 'AC-003'], touches: ['web/**', 'server/**', 'db/**'] })] }, cfg);
  assert.equal(big.problems.length, 1);
  assert.match(big.problems[0], /"everything" is about 19\.5 points; the cap is 13\.9/);
  assert.match(big.problems[0], /Split it into 4 tasks of about 5\.4 points/);
});

test('scorePlan: a plan shredded into tiny tasks comes back with the pairs to merge', () => {
  const s = planState();
  const chain = Array.from({ length: 8 }, (_, i) => task(`s${i}`, { size: 'S', touches: [`web/f${i}.ts`], depends_on: i ? [`s${i - 1}`] : [] }));
  const m = { ...getModel(s, cfg) };
  // make small tasks clearly wasteful, as they are once reviews prove expensive
  const pricey = deepMerge(cfg, { sizing: { overheadPoints: 4 } });
  const r = scorePlan(s, { tasks: chain }, pricey);
  assert.ok(r.waste > sz.maxPlanWaste, String(r.waste));
  assert.equal(r.problems.length, 1);
  assert.match(r.problems[0], /Most are too small: each pays a full build, gate and review round\. Merge neighbours in the same area, for example "s\d" \+ "s\d" \(2 \+ 2 points\)/);
  assert.equal(scorePlan(s, { tasks: chain.slice(0, 3) }, pricey).problems.length, 0); // too few tasks to be worth a repair round
  assert.ok(m.lo < 2); // under the default model an S task is still acceptable on its own
});

test('scorePlan: milestones are limited by the verification cycles left, and overlapping paths that serialise the plan are named', () => {
  const s = planState();
  const tight = deepMerge(cfg, { limits: { maxVerifyCycles: 4 } });
  const many = scorePlan(s, { tasks: ['M0', 'M1', 'M2', 'M3'].map((mid, i) => task(`t${i}`, { milestone: mid, touches: [`web/${i}/**`] })) }, tight);
  assert.match(many.problems.join('\n'), /4 milestones have open work, but only 4 verification cycles remain.*Use at most 2 milestones/);

  const wide = ['a', 'b', 'c', 'd'].map((k) => task(k, { touches: ['web/**'] })); // independent, but all claim the same tree
  const serial = scorePlan(s, { tasks: wide }, cfg);
  assert.ok(serial.claimsLoss >= 0.9, String(serial.claimsLoss)); // two slots, yet they run one at a time
  assert.match(serial.problems.join('\n'), /overlapping `touches` make this plan 100% slower.*a \+ b/);
  const narrow = scorePlan(s, { tasks: wide.map((t) => ({ ...t, touches: [`web/${t.key}/**`] })) }, cfg);
  assert.equal(narrow.claimsLoss, 0);
  assert.deepEqual(narrow.problems, []);
});

test('progress is weighted by size', () => {
  const s = planState();
  applyPlan(s, { tasks: [task('small', { size: 'S' }), task('large', { size: 'L', acceptance: ['AC-001'] })] });
  s.tasks['T-001'].status = 'merged';
  assert.deepEqual(progress(s, cfg), { done: 2, total: 13.5, pct: 15 }); // one of two tasks, but 15% of the work
});

// ---- the loop acting on it ------------------------------------------------------

const prd3 = { prd: '# PRD\n- **AC-001** (must) a.txt says good\n- **AC-002** (must) b.txt says good\n- **AC-003** (should) c.txt exists\n' };
const huge = { key: 'all', title: 'Everything', description: 'do it all', area: 'web', size: 'L', acceptance: ['AC-001', 'AC-002', 'AC-003'], touches: ['web/**', 'server/**', 'db/**'] };
const split = {
  summary: 'Three slices.',
  tasks: [
    { key: 'a', title: 'A', description: 'make a', area: 'web', acceptance: ['AC-001'], touches: ['a.txt'] },
    { key: 'b', title: 'B', description: 'make b', area: 'server', acceptance: ['AC-002'], touches: ['b.txt'] },
    { key: 'c', title: 'C', description: 'make c', area: 'web', acceptance: ['AC-003'], touches: ['c.txt'] },
  ],
};
const good = { 'T-001': [{ write: { 'a.txt': 'good\n' } }], 'T-002': [{ write: { 'b.txt': 'good\n' } }], 'T-003': [{ write: { 'c.txt': 'ok\n' } }] };

test('an oversized plan is sent back to the planner with the sizing problem, and the repaired plan runs to done', async () => {
  const p = project({ plans: [{ output: { summary: 'One big task.', tasks: [huge] } }, { output: split }], tasks: good }, {}, prd3);
  try {
    assert.equal((await p.run()).reason, 'done');
    const planner = p.calls().filter((c) => c.role === 'planner');
    assert.equal(planner.length, 2);
    assert.match(planner[0].prompt, /## Task size[\s\S]*Aim for about 5\.4 points per task[\s\S]*A task above 13\.9 points is sent back/);
    assert.ok(planner[1].resumed); // the same session repairs its own plan
    assert.match(planner[1].prompt, /rejected by validation[\s\S]*Sizing: "all" is about 19\.5 points; the cap is 13\.9[\s\S]*Split it into 4 tasks/);
    const s = p.state();
    assert.equal(Object.keys(s.tasks).length, 3);
    assert.equal(s.sizing.ledger.length, 3);
    assert.match(p.read('STATE.md'), /\*\*Progress:\*\* 100% of planned work merged \(19\.5 of 19\.5 points; 3\/3 tasks\)/);
    assert.match(p.read('STATE.md'), /## Granularity[\s\S]*\*\*Target:\*\*[\s\S]*\| T-001 \| 6\.5 \| 1 \| 0 \|/);
    assert.match(p.cli('sizing'), /Reward = merged − rounds/);
  } finally {
    p.cleanup();
  }
});

test('sizing problems never stop the loop: a plan the planner will not repair is accepted and built', async () => {
  const stubborn = { summary: 'One big task.', tasks: [huge] };
  const p = project({ plans: [{ output: stubborn }], tasks: { 'T-001': [{ write: { 'a.txt': 'good\n', 'b.txt': 'good\n', 'c.txt': 'ok\n' } }] } }, {}, prd3);
  try {
    assert.equal((await p.run()).reason, 'done');
    assert.equal(p.calls().filter((c) => c.role === 'planner').length, 3); // the plan and two repair rounds, then accepted
    const s = p.state();
    assert.equal(s.sizing.plan.problems, 1);
    assert.equal(s.tasks['T-001'].sizeChecked, true);
    assert.equal(s.sizing.replans, 0); // and it is not sent back again for the same reason
    assert.match(p.read('.harness/events.jsonl'), /sizing_accepted_with_problems/);
    assert.match(p.read('STATE.md'), /accepted with 1 sizing problem\(s\) the planner did not repair/);
  } finally {
    p.cleanup();
  }
});

test('a task whose sessions keep ending at a ceiling is declared oversized after two, and split by the planner', async () => {
  const partial = { output: { status: 'partial', summary: 'Ran out of room.', handoff: { done: ['half'], remaining: ['the rest'], gotchas: [], next_step: 'continue' } } };
  const p = project(
    {
      plans: [
        { output: { summary: 'A first.', tasks: [split.tasks[0], { ...split.tasks[1], depends_on: ['a'] }] } },
        { output: { summary: 'Split A in two.', cancel: ['T-001'], tasks: [{ key: 'a1', title: 'A part 1', description: 'half', area: 'web', size: 'S', touches: ['a1.txt'] }, { key: 'a2', title: 'A part 2', description: 'rest', area: 'web', size: 'S', acceptance: ['AC-001'], touches: ['a.txt'], depends_on: ['a1'] }] } },
      ],
      tasks: { 'T-001': [partial, partial, partial, partial], 'T-002': [{ write: { 'b.txt': 'good\n' } }], 'T-003': [{ write: { 'a1.txt': 'x\n' } }], 'T-004': [{ write: { 'a.txt': 'good\n' } }] },
    },
    {},
    { prd: '- **AC-001** (must) a\n- **AC-002** (must) b\n' },
  );
  try {
    assert.equal((await p.run()).reason, 'done');
    const calls = p.calls();
    assert.equal(calls.filter((c) => c.taskId === 'T-001').length, 2); // two strikes, not all four attempts
    const s = p.state();
    assert.equal(s.tasks['T-001'].status, 'cancelled');
    assert.deepEqual(s.tasks['T-002'].dependsOn, ['T-001']); // a cancelled dependency no longer holds T-002 back
    const lost = s.sizing.ledger.find((e) => e.id === 'T-001');
    assert.deepEqual([lost.merged, lost.why, lost.rounds, lost.ceilings], [false, 'oversized', 2, 2]);
    const replan = calls.filter((c) => c.role === 'planner')[1].prompt;
    assert.match(replan, /Reason: T-001 "A" is too big for one session/);
    assert.match(replan, /What was built so far is kept on branch task\/T-001/);
    assert.match(replan, /Turned out too big: T-001 "A" \(6\.5 points, 2 rounds, not finished\)/);
    assert.match(p.cli('sizing'), /\| T-001 \| [\d.]+ \| 2 \| 2 \|.*not merged \(oversized\) \| -\d\.\d+ \| too big/); // a negative reward
  } finally {
    p.cleanup();
  }
});

test('when measured failures tighten the cap, a task that has not started is held and sent to the planner to split', async () => {
  const bad = { write: { 'x.txt': 'BAD\n' } };
  const p = project(
    {
      plans: [
        {
          output: {
            summary: 'Two large slices, then a larger one.',
            tasks: [
              { key: 'a', title: 'A', description: 'make a', area: 'web', size: 'L', acceptance: ['AC-001'], touches: ['a.txt', 'x.txt'] },
              { key: 'b', title: 'B', description: 'make b', area: 'server', size: 'L', acceptance: ['AC-002'], touches: ['b.txt', 'y.txt'] },
              { key: 'c', title: 'C', description: 'make c', area: 'web', size: 'L', acceptance: ['AC-003'], done_when: ['one', 'two', 'three'], touches: ['c.txt'], depends_on: ['a', 'b'] },
            ],
          },
        },
        { output: { summary: 'C in two parts.', cancel: ['T-003'], tasks: [{ key: 'c1', title: 'C part 1', description: 'half', area: 'web', size: 'S', touches: ['c1.txt'] }, { key: 'c2', title: 'C part 2', description: 'rest', area: 'web', size: 'S', acceptance: ['AC-003'], touches: ['c.txt'], depends_on: ['c1'] }] } },
      ],
      tasks: {
        'T-001': [bad, bad, { write: { 'x.txt': 'fine\n', 'a.txt': 'good\n' } }],
        'T-002': [{ write: { 'y.txt': 'BAD\n' } }, { write: { 'y.txt': 'BAD\n' } }, { write: { 'y.txt': 'fine\n', 'b.txt': 'good\n' } }],
        'T-004': [{ write: { 'c1.txt': 'x\n' } }],
        'T-005': [{ write: { 'c.txt': 'ok\n' } }],
      },
    },
    {},
    prd3,
  );
  try {
    assert.equal((await p.run()).reason, 'done');
    const s = p.state();
    assert.equal(s.sizing.replans, 1);
    assert.equal(s.plan.replans, 0); // a sizing replan does not use the replan budget
    assert.ok(s.sizing.lambda > 0.06, String(s.sizing.lambda)); // two large tasks needed three rounds each
    assert.equal(s.tasks['T-003'].status, 'cancelled');
    assert.equal(p.calls().filter((c) => c.taskId === 'T-003').length, 0); // held: it never started
    const replan = p.calls().filter((c) => c.role === 'planner')[1].prompt;
    assert.match(replan, /Reason: Sizing: measured on this project so far, a task above 1\d\.\d points is more likely to fail a round than pass it\. Not started yet and above that: T-003 \(13 points\)/);
    assert.match(replan, /Not started and above the cap: T-003 "C" \(13 points\)/);
    assert.match(p.read('.harness/events.jsonl'), /sizing_replan/);
  } finally {
    p.cleanup();
  }
});
