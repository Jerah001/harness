// Granularity control: how big a task should be, how a plan is scored for it, and how the
// target adapts to what actually happens. Pure functions over state; no I/O.
//
// The model
// ---------
// Size is measured in points, estimated from what the planner declares:
//
//   raw    = base[size] + perCriterion·|acceptance| + perDoneWhen·|done_when|
//            + perExtraPath·(|touches| − 1) + perExtraArea·(areas touched − 1)
//   points = κ[area] · raw                 κ is learned per area from measured effort
//
// Every round on a task (build, gate, review) pays a fixed overhead O, and a task of size s
// passes a round with probability e^(−λ·s): bigger tasks fail more often and the whole round is
// paid again. Expected cost of a task, in points of work:
//
//   E(s) = (O + s) · e^(λ·s)
//
// Cost per point delivered, f(s) = E(s)/s, is high for tiny tasks (overhead dominates) and for
// huge ones (retries dominate). It is lowest at
//
//   s* = (O/2) · (√(1 + 4/(λ·O)) − 1)
//
// Penalty of a task   pen(s) = f(s)/f(s*) − 1          0 at the optimum, grows both ways
// Hard cap            cap    = ln(1/minFirstPass)/λ    above it a task is more likely to fail a round than pass
// Waste of a plan     ρ      = Σ E(sᵢ) / (f(s*)·Σ sᵢ) − 1
// Reward of a task    R      = merged − rounds·(O + s)/(s·f(s*))    >0 beat the ideal budget, <0 overspent it
//
// λ and κ are re-estimated from the outcome ledger after every task that merges or runs out of
// attempts, so the target moves towards what is actually landing in this project.
import { claims, tasksOf } from './graph.mjs';
import { globPrefix, globsOverlap, now } from './util.mjs';

const r1 = (x) => Math.round(x * 10) / 10;
const r2 = (x) => Math.round(x * 100) / 100;
const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
const sum = (xs) => xs.reduce((a, b) => a + b, 0);

export function ensureSizing(state) {
  state.sizing ??= { lambda: null, review: null, kappa: {}, beta: null, replans: 0, ledger: [], plan: null };
  return state.sizing;
}

/** Fix tasks come from triage and the cleaner is scheduled by the loop: the planner sizes neither. */
export const sized = (t) => t.kind !== 'fix' && t.role !== 'cleaner';

// ---- estimate -----------------------------------------------------------------

/** Top-level folders a task reaches into. Files at the root (lockfiles, config) do not count as an area. */
function areasTouched(t) {
  const tops = new Set((t.touches || []).filter((g) => g.includes('/')).map((g) => globPrefix(g).split('/')[0]).filter(Boolean));
  return Math.max(1, tops.size);
}

/** Points before calibration. Accepts a task from state or a task spec from a plan. */
export function rawPoints(t, sz) {
  const done = t.doneWhen || t.done_when || [];
  const size = sz.base[t.size] ? t.size : t.kind === 'fix' || t.role === 'cleaner' ? 'S' : 'M';
  return (
    sz.base[size] +
    sz.perCriterion * (t.acceptance || []).length +
    sz.perDoneWhen * Math.min(done.length, 6) +
    sz.perExtraPath * Math.max(0, Math.min((t.touches || []).length, 8) - 1) +
    sz.perExtraArea * (areasTouched(t) - 1)
  );
}

export const points = (t, m, sz) => r1((m.kappa[t.area] || 1) * rawPoints(t, sz));

// ---- cost model ---------------------------------------------------------------

export const optimum = (O, lambda) => (O / 2) * (Math.sqrt(1 + 4 / (lambda * O)) - 1);
export const expectedCost = (s, m) => (m.O + s) * Math.exp(m.lambda * s);
export const costPerPoint = (s, m) => expectedCost(s, m) / s;
export const penalty = (s, m) => costPerPoint(s, m) / m.fStar - 1;
export const firstPass = (s, m) => Math.exp(-m.lambda * s);

function bisect(fn, lo, hi) {
  for (let i = 0; i < 60; i++) {
    const mid = (lo + hi) / 2;
    if (fn(lo) * fn(mid) <= 0) hi = mid;
    else lo = mid;
  }
  return (lo + hi) / 2;
}

/** The current model: priors from config, replaced by measurements as the ledger fills. */
export function getModel(state, cfg) {
  const sz = cfg.sizing;
  const S = state.sizing || {};
  const lambda = S.lambda ?? sz.hazard;
  const O = sz.overheadPoints + (S.review ?? sz.reviewOverheadPoints);
  const sStar = optimum(O, lambda);
  const kappa = S.kappa || {};
  const m = { O, lambda, sStar, kappa, n: (S.ledger || []).length, calibrated: S.lambda != null };
  m.fStar = costPerPoint(sStar, m);
  // The cap loosens as tasks land, but never to more than twice the largest task that has
  // actually merged: the model is not trusted far outside the sizes it has seen.
  const priorCap = Math.log(1 / sz.minFirstPass) / sz.hazard;
  const largest = Math.max(0, ...(S.ledger || []).filter((e) => e.merged).map((e) => (kappa[e.area] || 1) * e.raw));
  m.cap = Math.min(Math.log(1 / sz.minFirstPass) / lambda, Math.max(priorCap, 2 * largest));
  m.lo = bisect((s) => penalty(s, m) - sz.bandPenalty, 0.01, sStar);
  m.hi = Math.min(m.cap, bisect((s) => penalty(s, m) - sz.bandPenalty, sStar, 500));
  return m;
}

// ---- calibration from outcomes -------------------------------------------------

/** Maximum a posteriori hazard: Bernoulli rounds with success e^(−λs), Gamma prior with mode λ0. */
export function fitHazard(obs, lambda0, weight) {
  const ll = (l) => {
    let v = weight * Math.log(l) - (weight / lambda0) * l;
    for (const o of obs) {
      v -= l * o.s * o.succ;
      if (o.fail > 0) v += o.fail * Math.log(1 - Math.exp(-l * o.s));
    }
    return v;
  };
  let a = 1e-4;
  let b = 2;
  const g = (Math.sqrt(5) - 1) / 2;
  for (let i = 0; i < 80; i++) {
    const c = b - g * (b - a);
    const d = a + g * (b - a);
    if (ll(c) > ll(d)) b = d;
    else a = c;
  }
  return (a + b) / 2;
}

/** Re-estimate κ (per area), the review share of the overhead, and λ from the ledger. */
export function calibrate(state, cfg) {
  const sz = cfg.sizing;
  const S = ensureSizing(state);
  const led = S.ledger;
  if (!led.length) return S;

  // κ: how much one raw point costs in each area, relative to the project average.
  const paid = led.filter((e) => e.buildUsd > 0 && e.rounds > 0);
  if (paid.length) {
    const usdPerRound = (es) => sum(es.map((e) => e.buildUsd / e.rounds));
    const beta0 = usdPerRound(paid) / sum(paid.map((e) => e.raw));
    const kappa = {};
    for (const area of new Set(paid.map((e) => e.area))) {
      const es = paid.filter((e) => e.area === area);
      const ratio = usdPerRound(es) / sum(es.map((e) => e.raw)) / beta0;
      kappa[area] = r2(clamp((sz.priorWeight * 1 + es.length * ratio) / (sz.priorWeight + es.length), 0.5, 2.5));
    }
    S.kappa = kappa;
    // β: dollars per calibrated point per round; turns the measured review cost into points.
    S.beta = usdPerRound(paid) / sum(paid.map((e) => (kappa[e.area] || 1) * e.raw));
    const reviewPts = sum(led.map((e) => e.reviewUsd || 0)) / sum(led.map((e) => e.rounds)) / S.beta;
    S.review = r2(clamp((sz.priorWeight * sz.reviewOverheadPoints + led.length * reviewPts) / (sz.priorWeight + led.length), 0, 6));
  }

  const obs = led.map((e) => ({ s: (S.kappa[e.area] || 1) * e.raw, succ: e.merged ? 1 : 0, fail: e.rounds - (e.merged ? 1 : 0) }));
  S.lambda = Number(clamp(fitHazard(obs, sz.hazard, sz.priorWeight), sz.hazard / 4, sz.hazard * 4).toFixed(4));
  S.updatedAt = now();
  return S;
}

/** Append one settled epoch of a task to the ledger and recalibrate. */
export function recordOutcome(state, cfg, t, merged, why = null) {
  const sz = cfg.sizing;
  const S = ensureSizing(state);
  const mt = t.metrics || {};
  if (!sized(t) || !t.attempt) return null;
  const entry = {
    id: t.id,
    title: t.title,
    area: t.area,
    size: t.size,
    raw: rawPoints(t, sz),
    rounds: t.attempt,
    merged: !!merged,
    why,
    ceilings: mt.ceilings || 0,
    buildUsd: r2(mt.buildUsd || 0),
    reviewUsd: r2(mt.reviewUsd || 0),
    turns: mt.turns || 0,
    diff: mt.diff || null,
    at: now(),
  };
  S.ledger.push(entry);
  t.metrics = { buildUsd: 0, reviewUsd: 0, turns: 0, ceilings: 0, diff: null }; // a retry starts a new epoch
  calibrate(state, cfg);
  return entry;
}

/** R > 0: delivered for less than the ideal budget for that much work. R < 0: overspent it. */
export function reward(entry, m) {
  const s = (m.kappa[entry.area] || 1) * entry.raw;
  return r2((entry.merged ? 1 : 0) - (entry.rounds * (m.O + s)) / (s * m.fStar));
}

export function verdict(entry, m, beta) {
  const s = (m.kappa[entry.area] || 1) * entry.raw;
  if (!entry.merged) return entry.ceilings || s > m.hi ? 'too big' : 'failed';
  if (entry.ceilings || entry.rounds >= 3) return s >= m.sStar ? 'too big' : 'hard';
  const observed = beta && entry.buildUsd ? entry.buildUsd / entry.rounds / beta : null;
  if (entry.rounds === 1 && observed != null && observed < m.lo) return 'small';
  return 'right';
}

// ---- plan scoring ---------------------------------------------------------------

function simulate(items, k, useClaims) {
  const byId = new Map(items.map((i) => [i.id, i]));
  const done = new Set();
  const started = new Set();
  const clashes = new Map();
  let running = [];
  let time = 0;
  const ready = (it) => it.deps.every((d) => !byId.has(d) || done.has(d));
  while (done.size < items.length) {
    for (const it of items) {
      if (running.length >= k) break;
      if (started.has(it.id) || !ready(it)) continue;
      const clash = useClaims && running.find((r) => globsOverlap(it.claims, r.item.claims));
      if (clash) {
        const key = [clash.item.id, it.id].sort().join(' + ');
        clashes.set(key, (clashes.get(key) || 0) + it.pts);
        continue;
      }
      started.add(it.id);
      running.push({ item: it, end: time + Math.max(it.pts, 0.1) });
    }
    if (!running.length) break; // unreachable after validation; never loop forever
    time = Math.min(...running.map((r) => r.end));
    for (const r of running) if (r.end <= time + 1e-9) done.add(r.item.id);
    running = running.filter((r) => r.end > time + 1e-9);
  }
  return { makespan: time, clashes };
}

function criticalPath(items) {
  const byId = new Map(items.map((i) => [i.id, i]));
  const memo = new Map();
  const walk = (it) => {
    if (memo.has(it.id)) return memo.get(it.id);
    memo.set(it.id, it.pts); // guards against a cycle that validation would have rejected
    const v = it.pts + Math.max(0, ...it.deps.filter((d) => byId.has(d)).map((d) => walk(byId.get(d))));
    memo.set(it.id, v);
    return v;
  };
  return Math.max(0, ...items.map(walk));
}

/**
 * Score a plan for granularity before it is applied.
 * problems: things the planner is asked to repair (each one comes with what to do about it).
 * advice:   worth knowing, not worth a repair round.
 */
export function scorePlan(state, plan, cfg) {
  const sz = cfg.sizing;
  const m = getModel(state, cfg);
  const cancel = new Set(plan?.cancel || []);
  const retry = new Set((plan?.retry || []).map((r) => r.id));
  const order = (id) => {
    const i = state.milestones.findIndex((x) => x.id === id);
    return i === -1 ? 999 : i;
  };

  const live = ['todo', 'rework', 'building', 'built', 'gating', 'gated', 'reviewing', 'approved', 'premerge'];
  const items = [];
  for (const t of tasksOf(state)) {
    if (t.priority !== 'mvp' || cancel.has(t.id)) continue;
    if (!live.includes(t.status) && !(t.status === 'blocked' && retry.has(t.id))) continue;
    items.push({ id: t.id, title: t.title, pts: points(t, m, sz), deps: t.dependsOn || [], claims: claims(t), milestone: t.milestone, area: t.area, isNew: false, sized: sized(t) });
  }
  const fresh = (plan?.tasks || []).filter((t) => t.key && t.priority !== 'later');
  for (const t of fresh) {
    items.push({ id: t.key, title: t.title, pts: points(t, m, sz), deps: t.depends_on || [], claims: claims(t), milestone: t.milestone || 'M0', area: t.area, isNew: true, sized: true });
  }
  const milestoneOrder = [...state.milestones.map((x) => x.id), ...(plan?.milestones || []).map((x) => x.id)];
  const rank = (id) => (milestoneOrder.includes(id) ? milestoneOrder.indexOf(id) : order(id));
  items.sort((a, b) => rank(a.milestone) - rank(b.milestone));

  const problems = [];
  const advice = [];
  const news = items.filter((i) => i.isNew);
  const target = r1(m.sStar);

  // 1. No task above the cap: it would more likely fail a round than pass it.
  for (const it of news.filter((i) => i.pts > m.cap)) {
    const parts = Math.max(2, Math.ceil(it.pts / m.sStar));
    problems.push(
      `Sizing: "${it.id}" is about ${it.pts} points; the cap is ${r1(m.cap)} (a task that size passes a round less than ${Math.round(sz.minFirstPass * 100)}% of the time). Split it into ${parts} tasks of about ${target} points each, ordered with depends_on.`,
    );
  }

  // 2. Waste of the new tasks against the ideal partition of the same work.
  const total = sum(news.map((i) => i.pts));
  const expected = sum(news.map((i) => expectedCost(i.pts, m)));
  const waste = total ? expected / (m.fStar * total) - 1 : 0;
  const merges = [];
  for (const b of news) {
    if (b.deps.length !== 1) continue;
    const a = news.find((x) => x.id === b.deps[0]);
    if (!a || a.area !== b.area || a.milestone !== b.milestone || a.pts + b.pts > m.hi) continue;
    if (news.some((x) => x !== b && x.deps.includes(a.id))) continue; // something else also waits on a: keep it separate
    const saving = expectedCost(a.pts, m) + expectedCost(b.pts, m) - expectedCost(a.pts + b.pts, m);
    if (saving > 0) merges.push({ a, b, saving });
  }
  merges.sort((x, y) => y.saving - x.saving);
  if (waste > sz.maxPlanWaste && news.length >= 4) {
    const small = news.filter((i) => i.pts < m.lo).length;
    const list = merges.slice(0, 4).map((x) => `"${x.a.id}" + "${x.b.id}" (${x.a.pts} + ${x.b.pts} points)`);
    const text = `Sizing: the new tasks are expected to cost ${Math.round(waste * 100)}% more than the same work in tasks of about ${target} points (limit ${Math.round(sz.maxPlanWaste * 100)}%).`;
    if (list.length && small * 2 >= news.length) problems.push(`${text} Most are too small: each pays a full build, gate and review round. Merge neighbours in the same area, for example ${list.join('; ')}.`);
    else advice.push(text);
  }

  // 3. Each open milestone costs a verification cycle; keep half of what is left for fix rounds.
  const open = [...new Set(items.map((i) => i.milestone))].filter((x) => x !== 'FIXES' && x !== 'UPKEEP');
  const cyclesLeft = Math.max(0, cfg.limits.maxVerifyCycles - state.verify.cycles);
  const allowed = Math.max(2, Math.floor(cyclesLeft / 2));
  if (news.length && open.length > allowed) {
    problems.push(
      `Sizing: ${open.length} milestones have open work, but only ${cyclesLeft} verification cycles remain and each completed milestone uses one; half are kept for fix rounds. Use at most ${allowed} milestones.`,
    );
  }

  // 4. How much the declared paths slow the plan down, by simulating the scheduler.
  const k = cfg.limits.concurrency;
  const withClaims = simulate(items, k, true);
  const depsOnly = simulate(items, k, false);
  const all = sum(items.map((i) => i.pts));
  const lower = Math.max(criticalPath(items), all / k);
  const loss = depsOnly.makespan ? withClaims.makespan / depsOnly.makespan - 1 : 0;
  const pairs = [...withClaims.clashes.entries()].sort((x, y) => y[1] - x[1]).map(([key]) => key);
  if (k > 1 && items.length >= 4 && loss > sz.maxClaimsLoss && news.length) {
    problems.push(
      `Sizing: overlapping \`touches\` make this plan ${Math.round(loss * 100)}% slower than its dependencies require (limit ${Math.round(sz.maxClaimsLoss * 100)}%), because tasks that could run in parallel wait for each other: ${pairs.slice(0, 4).join('; ')}. Narrow their \`touches\` to the files each really edits, or give the shared file to one earlier task.`,
    );
  } else if (k > 1 && loss > 0.15) advice.push(`Overlapping paths make the plan ${Math.round(loss * 100)}% slower than its dependencies require (${pairs.slice(0, 3).join('; ')}).`);

  const big = news.filter((i) => i.pts > m.hi && i.pts <= m.cap);
  if (big.length) advice.push(`Above the comfortable range (${r1(m.hi)} points) but under the cap: ${big.map((i) => `${i.id} (${i.pts})`).join(', ')}.`);

  return {
    model: m,
    items,
    newTasks: news.length,
    totalPoints: r1(all),
    waste: r2(waste),
    makespan: r1(withClaims.makespan),
    parallelEfficiency: withClaims.makespan ? r2(lower / withClaims.makespan) : 1,
    claimsLoss: r2(loss),
    milestones: { open: open.length, allowed },
    problems,
    advice,
  };
}

// ---- during the run --------------------------------------------------------------

/** Tasks not started yet that the current model says are above the cap. */
export function oversizedTodo(state, cfg) {
  const m = getModel(state, cfg);
  return tasksOf(state).filter((t) => t.status === 'todo' && t.attempt === 0 && t.priority === 'mvp' && sized(t) && !t.sizeChecked && points(t, m, cfg.sizing) > m.cap);
}

/** Progress weighted by size, so a one-line fix and a vertical slice do not count the same. */
export function progress(state, cfg) {
  const m = getModel(state, cfg);
  const ts = tasksOf(state).filter((t) => t.priority === 'mvp' && t.status !== 'cancelled');
  const total = sum(ts.map((t) => points(t, m, cfg.sizing)));
  const done = sum(ts.filter((t) => t.status === 'merged').map((t) => points(t, m, cfg.sizing)));
  return { done: r1(done), total: r1(total), pct: total ? Math.round((100 * done) / total) : 0 };
}

/** Everything STATE.md, `harness sizing` and the planner brief show about granularity. */
export function sizingReport(state, cfg) {
  const sz = cfg.sizing;
  const S = ensureSizing(state);
  const m = getModel(state, cfg);
  const led = S.ledger;
  const rounds = sum(led.map((e) => e.rounds));
  const merged = led.filter((e) => e.merged);
  const firstTime = led.filter((e) => e.merged && e.rounds === 1).length;
  const expectedFirst = led.length ? sum(led.map((e) => firstPass((m.kappa[e.area] || 1) * e.raw, m))) / led.length : null;
  const paid = sum(led.map((e) => e.rounds * (m.O + (m.kappa[e.area] || 1) * e.raw)));
  const ideal = m.fStar * sum(merged.map((e) => (m.kappa[e.area] || 1) * e.raw));
  const rows = led.map((e) => ({ ...e, points: r1((m.kappa[e.area] || 1) * e.raw), reward: reward(e, m), verdict: verdict(e, m, S.beta) }));
  const ahead = tasksOf(state)
    .filter((t) => t.status === 'todo' && t.priority === 'mvp' && sized(t))
    .map((t) => ({ id: t.id, title: t.title, points: points(t, m, sz), held: t.hold === 'resize' }));
  return {
    model: m,
    target: r1(m.sStar),
    lo: r1(m.lo),
    hi: r1(m.hi),
    cap: r1(m.cap),
    settled: led.length,
    rounds,
    firstPassRate: led.length ? firstTime / led.length : null,
    expectedFirstPass: expectedFirst,
    efficiency: paid ? r2(ideal / paid) : null,
    rows,
    tooBig: rows.filter((r) => r.verdict === 'too big'),
    small: rows.filter((r) => r.verdict === 'small'),
    aboveCap: ahead.filter((t) => t.points > m.cap),
    aboveRange: ahead.filter((t) => t.points > m.hi && t.points <= m.cap),
    plan: S.plan,
    replans: S.replans,
  };
}

/** The formula in words, for briefs and reports. */
export function formulaText(cfg, m) {
  const sz = cfg.sizing;
  const k = Object.entries(m.kappa).filter(([, v]) => v !== 1);
  return `points = base (S ${sz.base.S}, M ${sz.base.M}, L ${sz.base.L}) + ${sz.perCriterion} per acceptance criterion + ${sz.perDoneWhen} per done_when check + ${sz.perExtraPath} per path in \`touches\` after the first + ${sz.perExtraArea} per extra top-level folder touched${k.length ? `, times a measured factor per area (${k.map(([a, v]) => `${a} ×${v}`).join(', ')})` : ''}`;
}
